import sys
import logging
import rds_config
import pymysql
import random
import datetime
#rds settings
rds_host  = rds_config.RDSHost
name = rds_config.RDSUser
password = rds_config.RDSPassword
db_name = rds_config.RDSDBName



logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=90)
except Exception as inst:
    logger.error(inst)
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
def handler(event, context):
    """
    This function fetches content from mysql RDS instance
    """

    item_count = 0
    patid = random.randint(70,90)
   
    with conn.cursor() as cur:
        rndlabvalue  = random.uniform(190.0,240.0)
        dt = datetime.datetime.now()
        cur.execute('insert into diabetes.Labs  values(3001, "Glucose",'+str(patid)+','+ str(rndlabvalue) +',"' + str(dt) +'")')
        rndlabvalue  = random.uniform(190.0,240.0)
        dt = datetime.datetime.now()
        cur.execute('insert into diabetes.Labs  values(3001, "Glucose",'+str(patid)+','+ str(rndlabvalue) +',"' + str(dt) +'")')
        rndlabvalue  = random.uniform(190.0,240.0)
        dt = datetime.datetime.now()
        cur.execute('insert into diabetes.Labs  values(3001, "Glucose",'+str(patid)+','+ str(rndlabvalue) +',"' + str(dt) +'")')
        conn.commit()
       

    return "Added %d items from RDS MySQL table" %(item_count)
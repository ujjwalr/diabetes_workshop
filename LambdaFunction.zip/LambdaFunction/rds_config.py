#config file containing credentials for rds mysql instance
# Replace RDS host with your RDS hostname available in the outputs tab of the CloudFormation script. 
RDSHost = "Your_RDS_Host"
RDSUser = "master"
RDSPassword = "4we4df234"
RDSDBName = "diabetes"
#config file containing credentials for rds mysql instance
db_username = "master"
db_password = "master123"
db_name = "diabetes"
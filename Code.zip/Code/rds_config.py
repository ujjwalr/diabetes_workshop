#config file containing credentials for rds mysql instance
db_source = "sd74is1d8txuav.cxy7or0esjwv.us-east-2.rds.amazonaws.com"
db_username = "master"
db_password = "4we4df234"
db_name = "diabetes"